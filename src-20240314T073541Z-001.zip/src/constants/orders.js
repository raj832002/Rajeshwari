export const allOrders = [
  {
    id: 1,
    orderID: "ORD001",
    customerName: "Rohan",
    orderDate: "2024-02-04",
    status: "Processing",
  },
  {
    id: 2,
    orderID: "ORD002",
    customerName: "Aditya",
    orderDate: "2024-04-05",
    status: "Processing",
  },
  {
    id: 3,
    orderID: "ORD003",
    customerName: "Anil",
    orderDate: "2023-11-25",
    status: "Processing",
  },
  {
    id: 4,
    orderID: "ORD004",
    customerName: "Abhishek",
    orderDate: "2024-03-10",
    status: "Processing",
  },
];